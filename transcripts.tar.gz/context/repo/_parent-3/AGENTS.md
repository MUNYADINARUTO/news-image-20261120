# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

- In a bash script, bare `wait` waits for ALL background jobs, including a long-running daemon started with `nohup ... &` in the same script — it will hang forever on the daemon. Always `wait` on specific PIDs (`wait $pid1 $pid2`) or check jobs individually; never use bare `wait` in a script that also starts a daemon.
- `process.kill` on an exec session tears down the whole process tree, including `nohup`'d daemons started inside it. To stop a stuck verification script without killing its daemon, kill only the shell PID, or start the daemon from a separate short-lived exec call (a normally-completed session leaves a `nohup`'d child running).
- VM restarts wipe /tmp, kill all processes, and remove apt/npm-global installs (vapi, secret-tool, baw); only `~` persists. After a restart, reinstall what's missing and restart dbus-daemon + the custom secret service before assuming any login/session still works.
- Long CPU jobs launched from short-lived proactivity runs die when the run's session is torn down — `setsid nohup` does NOT save them (proven twice with the chess v17 match, 2026-11-13). Launch them via `systemd-run --scope --unit=<name>` so systemd owns the process and it survives the run.
- fastmint fire.js lock key = sha256(to | data | value) only — it does NOT include the from wallet. A second wallet's identical free mint (e.g. marnie's PXIO mint(1)) hits the first wallet's lock file. Fix: read the lock file, verify its tx belongs to the other wallet's completed mint, delete it, then fire the distinct mint (user-authorized only). Proven 2026-11-17 with marnie PXIO #12013.
- Binance Developer Mode is PER Binance account, not per CLI session: switching baw from darklock to marnie (2026-11-17) hit "Developer Mode is off/expired" — the marnie account needed it enabled separately in the Binance app (Agentic Wallet → Settings → Developer Mode). Once enabled it lasts ~7 days.
